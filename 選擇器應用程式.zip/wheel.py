import tkinter as tk
import math
import random
import time
from typing import List, Callable
from styles import WHEEL_COLORS, FONTS, COLORS

class Wheel(tk.Canvas):
    """轉盤元件，用於隨機選擇選項"""
    
    def __init__(self, master, **kwargs):
        """初始化轉盤
        
        Args:
            master: 父元件
            **kwargs: Canvas 的其他參數
        """
        super().__init__(master, **kwargs)
        self.options = []
        self.colors = WHEEL_COLORS
        self.angle = 0
        self.rotation_speed = 0
        self.is_spinning = False
        self.result_callback = None
        self.center_x = self.winfo_reqwidth() / 2
        self.center_y = self.winfo_reqheight() / 2
        self.radius = min(self.center_x, self.center_y) - 20
        self.selected_option = None
        self.highlight_selected = False
        
        # 綁定視窗大小變更事件
        self.bind("<Configure>", self._on_resize)
        
    def _on_resize(self, event):
        """處理視窗大小變更事件"""
        self.center_x = event.width / 2
        self.center_y = event.height / 2
        self.radius = min(self.center_x, self.center_y) - 20
        self.draw_wheel()
        
    def set_options(self, options: List[str]):
        """設定轉盤選項
        
        Args:
            options: 選項列表
        """
        self.options = options
        self.highlight_selected = False
        self.draw_wheel()
        
    def set_result_callback(self, callback: Callable[[str], None]):
        """設定結果回調函數
        
        Args:
            callback: 回調函數，接收選中的選項作為參數
        """
        self.result_callback = callback
        
    def draw_wheel(self):
        """繪製轉盤"""
        self.delete("all")  # 清除畫布
        
        if not self.options:
            # 如果沒有選項，繪製提示文字
            self.create_text(
                self.center_x, self.center_y,
                text="請先選擇或新增問題",
                font=FONTS["subtitle"],
                fill=COLORS["light_text"]
            )
            return
            
        # 繪製外圈
        self.create_oval(
            self.center_x - self.radius - 5,
            self.center_y - self.radius - 5,
            self.center_x + self.radius + 5,
            self.center_y + self.radius + 5,
            fill="",
            outline=COLORS["primary"],
            width=3
        )
            
        # 計算每個選項的角度
        angle_per_option = 360.0 / len(self.options)
        
        # 繪製每個選項的扇形
        for i, option in enumerate(self.options):
            start_angle = self.angle + i * angle_per_option
            end_angle = start_angle + angle_per_option
            
            # 判斷是否為選中的選項
            is_selected = self.highlight_selected and option == self.selected_option
            
            # 繪製扇形
            fill_color = self.colors[i % len(self.colors)]
            if is_selected:
                # 選中的選項使用更亮的顏色
                fill_color = COLORS["accent"]
                
            self.create_arc(
                self.center_x - self.radius,
                self.center_y - self.radius,
                self.center_x + self.radius,
                self.center_y + self.radius,
                start=start_angle,
                extent=angle_per_option,
                fill=fill_color,
                outline="white",
                width=2,
                style=tk.PIESLICE
            )
            
            # 計算文字位置 (在扇形中心)
            text_angle = math.radians(start_angle + angle_per_option / 2)
            text_radius = self.radius * 0.7  # 文字距離中心的距離
            text_x = self.center_x + text_radius * math.cos(text_angle)
            text_y = self.center_y - text_radius * math.sin(text_angle)
            
            # 繪製文字
            text_color = "black"
            if is_selected:
                text_color = "white"
                
            self.create_text(
                text_x, text_y,
                text=option,
                font=FONTS["wheel_text"],
                fill=text_color
            )
        
        # 繪製中心圓
        self.create_oval(
            self.center_x - 15,
            self.center_y - 15,
            self.center_x + 15,
            self.center_y + 15,
            fill=COLORS["primary"],
            outline="white",
            width=2
        )
        
        # 繪製指針
        self.create_polygon(
            self.center_x, self.center_y - self.radius - 15,
            self.center_x - 12, self.center_y - self.radius + 5,
            self.center_x + 12, self.center_y - self.radius + 5,
            fill=COLORS["accent"],
            outline="white",
            width=2
        )
        
        # 如果正在旋轉，添加閃爍效果
        if self.is_spinning:
            # 繪製動態效果
            for i in range(8):
                angle = math.radians(self.angle + i * 45)
                x1 = self.center_x + (self.radius + 10) * math.cos(angle)
                y1 = self.center_y - (self.radius + 10) * math.sin(angle)
                x2 = self.center_x + (self.radius + 20) * math.cos(angle)
                y2 = self.center_y - (self.radius + 20) * math.sin(angle)
                
                self.create_line(
                    x1, y1, x2, y2,
                    fill=COLORS["accent"],
                    width=3,
                    dash=(5, 3)
                )
        
    def spin(self):
        """開始旋轉轉盤"""
        if self.is_spinning or not self.options:
            return
            
        self.is_spinning = True
        self.highlight_selected = False
        self.selected_option = None
        self.rotation_speed = random.uniform(15.0, 25.0)  # 增加初始旋轉速度
        self._spin_animation()
        
    def _spin_animation(self):
        """轉盤旋轉動畫"""
        if self.rotation_speed <= 0.3:
            # 停止旋轉
            self.is_spinning = False
            self._determine_result()
            return
            
        # 更新角度
        self.angle = (self.angle + self.rotation_speed) % 360
        self.draw_wheel()
        
        # 減緩旋轉速度
        deceleration = 0.97 if self.rotation_speed > 5 else 0.985
        self.rotation_speed *= deceleration
        
        # 繼續動畫，根據速度調整更新頻率
        delay = 20 if self.rotation_speed > 10 else 30
        self.after(delay, self._spin_animation)
        
    def _determine_result(self):
        """確定轉盤結果"""
        if not self.options:
            return
            
        # 計算每個選項的角度
        angle_per_option = 360.0 / len(self.options)
        
        # 計算指針指向的選項索引
        # 指針固定在頂部 (270度)，所以需要計算相對於轉盤旋轉角度的位置
        pointer_angle = (270 - self.angle) % 360
        selected_index = int(pointer_angle / angle_per_option)
        
        # 獲取選中的選項
        self.selected_option = self.options[selected_index]
        
        # 高亮顯示選中的選項
        self.highlight_selected = True
        self.draw_wheel()
        
        # 添加結果動畫效果
        self._animate_result()
        
    def _animate_result(self):
        """結果動畫效果"""
        # 閃爍效果
        def flash(count=0):
            if count >= 6:  # 閃爍3次
                # 調用結果回調函數
                if self.result_callback:
                    self.result_callback(self.selected_option)
                return
                
            # 切換高亮狀態
            self.highlight_selected = not self.highlight_selected
            self.draw_wheel()
            
            # 繼續閃爍
            self.after(200, lambda: flash(count + 1))
            
        # 開始閃爍動畫
        flash()