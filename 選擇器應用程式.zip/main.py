import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
import os
import sys
from typing import List, Dict, Any

from data_model import DataModel
from wheel import Wheel
from styles import COLORS, FONTS, BUTTON_STYLES, LISTBOX_STYLES, FRAME_STYLES, LABELFRAME_STYLES, RESULT_STYLES

class RandomSelectorApp:
    """隨機選擇器應用程式主類別"""
    
    def __init__(self, root):
        """初始化應用程式
        
        Args:
            root: Tkinter 根視窗
        """
        self.root = root
        self.root.title("✨ 隨機選擇器 ✨")
        self.root.geometry("900x650")
        self.root.minsize(700, 500)
        self.root.configure(bg=COLORS["background"])
        
        # 設定應用程式圖標 - 使用標題文字代替
        self.root.title("🎯 隨機選擇器 🎲")
        
        # 載入資料模型
        self.data_model = DataModel()
        
        # 目前選擇的問題
        self.current_question = None
        
        # 建立 UI
        self._create_ui()
        
        # 載入問題列表
        self._load_questions()
    
    def _create_ui(self):
        """建立使用者介面"""
        # 主框架
        main_frame = tk.Frame(self.root, **FRAME_STYLES)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=15, pady=15)
        
        # 標題標籤
        title_label = tk.Label(
            main_frame, 
            text="隨機選擇器", 
            font=FONTS["title"],
            fg=COLORS["primary"],
            bg=COLORS["background"],
            pady=10
        )
        title_label.pack(side=tk.TOP, fill=tk.X)
        
        # 左側問題列表區域
        left_frame = tk.LabelFrame(
            main_frame, 
            text="問題列表", 
            font=FONTS["subtitle"],
            fg=COLORS["primary"],
            bg=COLORS["background"],
            relief="groove",
            borderwidth=2
        )
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=False, padx=10, pady=10, ipadx=5, ipady=5)
        
        # 問題列表
        self.question_listbox = tk.Listbox(
            left_frame, 
            width=25, 
            font=FONTS["list"],
            **LISTBOX_STYLES
        )
        self.question_listbox.pack(side=tk.TOP, fill=tk.BOTH, expand=True, padx=8, pady=8)
        self.question_listbox.bind("<<ListboxSelect>>", self._on_question_select)
        
        # 問題管理按鈕
        question_buttons_frame = tk.Frame(left_frame, bg=COLORS["background"])
        question_buttons_frame.pack(side=tk.BOTTOM, fill=tk.X, padx=8, pady=8)
        
        # 使用自訂按鈕樣式
        add_question_btn = tk.Button(
            question_buttons_frame, 
            text="新增問題", 
            command=self._add_question,
            font=FONTS["button"],
            **BUTTON_STYLES["normal"]
        )
        add_question_btn.pack(side=tk.LEFT, padx=3, pady=3, fill=tk.X, expand=True)
        
        edit_question_btn = tk.Button(
            question_buttons_frame, 
            text="編輯問題", 
            command=self._edit_question,
            font=FONTS["button"],
            **BUTTON_STYLES["normal"]
        )
        edit_question_btn.pack(side=tk.LEFT, padx=3, pady=3, fill=tk.X, expand=True)
        
        delete_question_btn = tk.Button(
            question_buttons_frame, 
            text="刪除問題", 
            command=self._delete_question,
            font=FONTS["button"],
            **BUTTON_STYLES["accent"]
        )
        delete_question_btn.pack(side=tk.LEFT, padx=3, pady=3, fill=tk.X, expand=True)
        
        # 中間轉盤區域
        center_frame = tk.LabelFrame(
            main_frame, 
            text="轉盤", 
            font=FONTS["subtitle"],
            fg=COLORS["primary"],
            bg=COLORS["background"],
            relief="groove",
            borderwidth=2
        )
        center_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=10, pady=10, ipadx=5, ipady=5)
        
        # 轉盤
        self.wheel = Wheel(center_frame, bg="white", highlightthickness=0)
        self.wheel.pack(fill=tk.BOTH, expand=True, padx=15, pady=15)
        self.wheel.set_result_callback(self._on_wheel_result)
        
        # 轉盤按鈕
        spin_button = tk.Button(
            center_frame, 
            text="開始轉盤", 
            command=self._spin_wheel,
            font=FONTS["button"],
            **BUTTON_STYLES["success"]
        )
        spin_button.pack(side=tk.BOTTOM, pady=15)
        
        # 右側選項管理區域
        right_frame = tk.LabelFrame(
            main_frame, 
            text="選項管理", 
            font=FONTS["subtitle"],
            fg=COLORS["primary"],
            bg=COLORS["background"],
            relief="groove",
            borderwidth=2
        )
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=False, padx=10, pady=10, ipadx=5, ipady=5)
        
        # 選項列表
        self.options_listbox = tk.Listbox(
            right_frame, 
            width=25, 
            font=FONTS["list"],
            **LISTBOX_STYLES
        )
        self.options_listbox.pack(side=tk.TOP, fill=tk.BOTH, expand=True, padx=8, pady=8)
        
        # 選項管理按鈕
        options_buttons_frame = tk.Frame(right_frame, bg=COLORS["background"])
        options_buttons_frame.pack(side=tk.BOTTOM, fill=tk.X, padx=8, pady=8)
        
        add_option_btn = tk.Button(
            options_buttons_frame, 
            text="新增選項", 
            command=self._add_option,
            font=FONTS["button"],
            **BUTTON_STYLES["normal"]
        )
        add_option_btn.pack(side=tk.LEFT, padx=3, pady=3, fill=tk.X, expand=True)
        
        edit_option_btn = tk.Button(
            options_buttons_frame, 
            text="編輯選項", 
            command=self._edit_option,
            font=FONTS["button"],
            **BUTTON_STYLES["normal"]
        )
        edit_option_btn.pack(side=tk.LEFT, padx=3, pady=3, fill=tk.X, expand=True)
        
        delete_option_btn = tk.Button(
            options_buttons_frame, 
            text="刪除選項", 
            command=self._delete_option,
            font=FONTS["button"],
            **BUTTON_STYLES["accent"]
        )
        delete_option_btn.pack(side=tk.LEFT, padx=3, pady=3, fill=tk.X, expand=True)
    
    def _load_questions(self):
        """載入問題列表"""
        self.question_listbox.delete(0, tk.END)
        
        questions = self.data_model.get_all_questions()
        for question in questions:
            self.question_listbox.insert(tk.END, question["title"])
            
        # 如果有問題，預設選擇第一個
        if questions:
            self.question_listbox.selection_set(0)
            self._on_question_select(None)
    
    def _on_question_select(self, event):
        """處理問題選擇事件"""
        selected_indices = self.question_listbox.curselection()
        if not selected_indices:
            return
            
        selected_index = selected_indices[0]
        questions = self.data_model.get_all_questions()
        
        if 0 <= selected_index < len(questions):
            self.current_question = questions[selected_index]
            self._load_options()
            self.wheel.set_options(self.current_question["options"])
    
    def _load_options(self):
        """載入選項列表"""
        self.options_listbox.delete(0, tk.END)
        
        if self.current_question:
            for option in self.current_question["options"]:
                self.options_listbox.insert(tk.END, option)
    
    def _add_question(self):
        """新增問題"""
        title = simpledialog.askstring("新增問題", "請輸入問題標題:")
        if not title:
            return
            
        options = []
        while True:
            option = simpledialog.askstring("新增選項", "請輸入選項 (取消結束):")
            if not option:
                break
            options.append(option)
            
        if not options:
            messagebox.showwarning("警告", "問題必須至少有一個選項!")
            return
            
        self.data_model.add_question(title, options)
        self._load_questions()
        
        # 選擇新增的問題
        questions = self.data_model.get_all_questions()
        self.question_listbox.selection_set(len(questions) - 1)
        self._on_question_select(None)
    
    def _edit_question(self):
        """編輯問題"""
        if not self.current_question:
            messagebox.showinfo("提示", "請先選擇一個問題!")
            return
            
        title = simpledialog.askstring("編輯問題", "請輸入新的問題標題:", initialvalue=self.current_question["title"])
        if title:
            self.data_model.update_question(self.current_question["id"], title=title)
            self._load_questions()
            
            # 找到並選擇編輯後的問題
            questions = self.data_model.get_all_questions()
            for i, question in enumerate(questions):
                if question["id"] == self.current_question["id"]:
                    self.question_listbox.selection_set(i)
                    break
            
            self._on_question_select(None)
    
    def _delete_question(self):
        """刪除問題"""
        if not self.current_question:
            messagebox.showinfo("提示", "請先選擇一個問題!")
            return
            
        if messagebox.askyesno("確認刪除", f"確定要刪除問題「{self.current_question['title']}」嗎?"):
            self.data_model.delete_question(self.current_question["id"])
            self.current_question = None
            self._load_questions()
            self.wheel.set_options([])
    
    def _add_option(self):
        """新增選項"""
        if not self.current_question:
            messagebox.showinfo("提示", "請先選擇一個問題!")
            return
            
        option = simpledialog.askstring("新增選項", "請輸入選項內容:")
        if option:
            options = self.current_question["options"].copy()
            options.append(option)
            self.data_model.update_question(self.current_question["id"], options=options)
            
            # 重新載入選項
            self._on_question_select(None)
    
    def _edit_option(self):
        """編輯選項"""
        if not self.current_question:
            messagebox.showinfo("提示", "請先選擇一個問題!")
            return
            
        selected_indices = self.options_listbox.curselection()
        if not selected_indices:
            messagebox.showinfo("提示", "請先選擇一個選項!")
            return
            
        selected_index = selected_indices[0]
        old_option = self.current_question["options"][selected_index]
        
        new_option = simpledialog.askstring("編輯選項", "請輸入新的選項內容:", initialvalue=old_option)
        if new_option:
            options = self.current_question["options"].copy()
            options[selected_index] = new_option
            self.data_model.update_question(self.current_question["id"], options=options)
            
            # 重新載入選項
            self._on_question_select(None)
    
    def _delete_option(self):
        """刪除選項"""
        if not self.current_question:
            messagebox.showinfo("提示", "請先選擇一個問題!")
            return
            
        selected_indices = self.options_listbox.curselection()
        if not selected_indices:
            messagebox.showinfo("提示", "請先選擇一個選項!")
            return
            
        selected_index = selected_indices[0]
        option = self.current_question["options"][selected_index]
        
        if len(self.current_question["options"]) <= 1:
            messagebox.showwarning("警告", "問題必須至少有一個選項!")
            return
            
        if messagebox.askyesno("確認刪除", f"確定要刪除選項「{option}」嗎?"):
            options = self.current_question["options"].copy()
            del options[selected_index]
            self.data_model.update_question(self.current_question["id"], options=options)
            
            # 重新載入選項
            self._on_question_select(None)
    
    def _spin_wheel(self):
        """轉動轉盤"""
        if not self.current_question or not self.current_question["options"]:
            messagebox.showinfo("提示", "請先選擇一個有選項的問題!")
            return
            
        self.wheel.spin()
    
    def _on_wheel_result(self, result):
        """處理轉盤結果"""
        # 創建自定義結果對話框
        result_dialog = tk.Toplevel(self.root)
        result_dialog.title("✨ 選擇結果 ✨")
        result_dialog.geometry("400x250")
        result_dialog.configure(bg=COLORS["background"])
        result_dialog.transient(self.root)
        result_dialog.grab_set()
        
        # 確保對話框置中
        result_dialog.update_idletasks()
        width = result_dialog.winfo_width()
        height = result_dialog.winfo_height()
        x = (result_dialog.winfo_screenwidth() // 2) - (width // 2)
        y = (result_dialog.winfo_screenheight() // 2) - (height // 2)
        result_dialog.geometry(f"{width}x{height}+{x}+{y}")
        
        # 標題
        title_label = tk.Label(
            result_dialog,
            text="選擇結果",
            font=FONTS["title"],
            fg=COLORS["primary"],
            bg=COLORS["background"],
            pady=10
        )
        title_label.pack(pady=10)
        
        # 問題標題
        question_label = tk.Label(
            result_dialog,
            text=self.current_question["title"],
            font=FONTS["subtitle"],
            fg=COLORS["text"],
            bg=COLORS["background"],
            wraplength=350
        )
        question_label.pack(pady=5)
        
        # 結果框架
        result_frame = tk.Frame(
            result_dialog,
            bg=COLORS["primary"],
            padx=20,
            pady=15,
            relief="raised",
            borderwidth=1
        )
        result_frame.pack(pady=15, padx=20, fill=tk.X)
        
        # 結果文字
        result_label = tk.Label(
            result_frame,
            text=result,
            font=FONTS["result"],
            fg="white",
            bg=COLORS["primary"],
            wraplength=300
        )
        result_label.pack()
        
        # 確定按鈕
        ok_button = tk.Button(
            result_dialog,
            text="確定",
            command=result_dialog.destroy,
            font=FONTS["button"],
            **BUTTON_STYLES["success"],
            padx=30,
            pady=8
        )
        ok_button.pack(pady=15)

def main():
    """主程式入口"""
    root = tk.Tk()
    app = RandomSelectorApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()