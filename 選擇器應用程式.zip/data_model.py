import json
import os
from typing import List, Dict, Any

class DataModel:
    """資料模型類別，負責管理問題和選項的儲存與讀取"""
    
    def __init__(self, file_path: str = "questions.json"):
        """初始化資料模型
        
        Args:
            file_path: JSON 檔案路徑
        """
        self.file_path = file_path
        self.questions = []
        self.load_data()
    
    def load_data(self) -> None:
        """從 JSON 檔案載入資料"""
        if os.path.exists(self.file_path):
            try:
                with open(self.file_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    self.questions = data.get("questions", [])
            except Exception as e:
                print(f"載入資料時發生錯誤: {e}")
                self.questions = []
        else:
            # 如果檔案不存在，建立預設資料
            self.questions = [
                {
                    "id": 1,
                    "title": "午餐要吃什麼？",
                    "options": ["便當", "拉麵", "壽司", "漢堡"]
                },
                {
                    "id": 2,
                    "title": "週末去哪裡玩？",
                    "options": ["公園", "電影院", "咖啡廳", "博物館"]
                }
            ]
            self.save_data()
    
    def save_data(self) -> None:
        """將資料儲存至 JSON 檔案"""
        try:
            with open(self.file_path, 'w', encoding='utf-8') as f:
                json.dump({"questions": self.questions}, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"儲存資料時發生錯誤: {e}")
    
    def get_all_questions(self) -> List[Dict[str, Any]]:
        """取得所有問題
        
        Returns:
            問題列表
        """
        return self.questions
    
    def get_question_by_id(self, question_id: int) -> Dict[str, Any]:
        """根據 ID 取得問題
        
        Args:
            question_id: 問題 ID
            
        Returns:
            問題資料，若找不到則返回 None
        """
        for question in self.questions:
            if question["id"] == question_id:
                return question
        return None
    
    def add_question(self, title: str, options: List[str]) -> int:
        """新增問題
        
        Args:
            title: 問題標題
            options: 選項列表
            
        Returns:
            新問題的 ID
        """
        # 產生新的 ID (最大 ID + 1)
        new_id = 1
        if self.questions:
            new_id = max(q["id"] for q in self.questions) + 1
            
        new_question = {
            "id": new_id,
            "title": title,
            "options": options
        }
        
        self.questions.append(new_question)
        self.save_data()
        return new_id
    
    def update_question(self, question_id: int, title: str = None, options: List[str] = None) -> bool:
        """更新問題
        
        Args:
            question_id: 問題 ID
            title: 新標題 (可選)
            options: 新選項列表 (可選)
            
        Returns:
            是否更新成功
        """
        for i, question in enumerate(self.questions):
            if question["id"] == question_id:
                if title is not None:
                    self.questions[i]["title"] = title
                if options is not None:
                    self.questions[i]["options"] = options
                self.save_data()
                return True
        return False
    
    def delete_question(self, question_id: int) -> bool:
        """刪除問題
        
        Args:
            question_id: 問題 ID
            
        Returns:
            是否刪除成功
        """
        for i, question in enumerate(self.questions):
            if question["id"] == question_id:
                del self.questions[i]
                self.save_data()
                return True
        return False