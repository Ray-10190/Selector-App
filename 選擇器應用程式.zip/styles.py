"""
樣式設定模組，用於美化應用程式界面
"""

# 顏色定義
COLORS = {
    "primary": "#3498db",       # 主要顏色（藍色）
    "secondary": "#2ecc71",     # 次要顏色（綠色）
    "accent": "#e74c3c",        # 強調顏色（紅色）
    "background": "#f5f5f5",    # 背景顏色（淺灰）
    "text": "#2c3e50",          # 文字顏色（深藍灰）
    "light_text": "#7f8c8d",    # 淺色文字
    "border": "#bdc3c7",        # 邊框顏色
    "hover": "#2980b9",         # 懸停顏色
    "success": "#27ae60",       # 成功顏色
    "warning": "#f39c12",       # 警告顏色
    "error": "#c0392b",         # 錯誤顏色
}

# 轉盤顏色
WHEEL_COLORS = [
    "#3498db",  # 藍色
    "#2ecc71",  # 綠色
    "#e74c3c",  # 紅色
    "#f39c12",  # 橙色
    "#9b59b6",  # 紫色
    "#1abc9c",  # 青色
    "#34495e",  # 深藍灰
    "#16a085",  # 深青色
    "#d35400",  # 深橙色
    "#8e44ad",  # 深紫色
]

# 字體設定
FONTS = {
    "title": ("Microsoft JhengHei UI", 16, "bold"),
    "subtitle": ("Microsoft JhengHei UI", 14, "bold"),
    "button": ("Microsoft JhengHei UI", 10),
    "text": ("Microsoft JhengHei UI", 10),
    "list": ("Microsoft JhengHei UI", 11),
    "wheel_text": ("Microsoft JhengHei UI", 10, "bold"),
    "result": ("Microsoft JhengHei UI", 14, "bold"),
}

# 按鈕樣式
BUTTON_STYLES = {
    "normal": {
        "background": COLORS["primary"],
        "foreground": "white",
        "activebackground": COLORS["hover"],
        "activeforeground": "white",
        "relief": "flat",
        "borderwidth": 0,
        "padx": 10,
        "pady": 5,
    },
    "accent": {
        "background": COLORS["accent"],
        "foreground": "white",
        "activebackground": COLORS["error"],
        "activeforeground": "white",
        "relief": "flat",
        "borderwidth": 0,
        "padx": 10,
        "pady": 5,
    },
    "success": {
        "background": COLORS["success"],
        "foreground": "white",
        "activebackground": COLORS["secondary"],
        "activeforeground": "white",
        "relief": "flat",
        "borderwidth": 0,
        "padx": 10,
        "pady": 5,
    },
}

# 列表框樣式
LISTBOX_STYLES = {
    "background": "white",
    "foreground": COLORS["text"],
    "selectbackground": COLORS["primary"],
    "selectforeground": "white",
    "relief": "flat",
    "borderwidth": 1,
    "highlightthickness": 1,
    "highlightcolor": COLORS["primary"],
    "highlightbackground": COLORS["border"],
}

# 框架樣式
FRAME_STYLES = {
    "background": COLORS["background"],
    "relief": "flat",
    "borderwidth": 0,
    "padx": 10,
    "pady": 10,
}

# 標籤框架樣式
LABELFRAME_STYLES = {
    "background": COLORS["background"],
    "foreground": COLORS["primary"],
    "relief": "groove",
    "borderwidth": 1,
    "padx": 10,
    "pady": 10,
}

# 結果顯示樣式
RESULT_STYLES = {
    "background": COLORS["primary"],
    "foreground": "white",
    "relief": "flat",
    "borderwidth": 0,
    "padx": 20,
    "pady": 10,
}